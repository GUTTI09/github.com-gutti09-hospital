import uuid
import time
import json
import os
import random
from datetime import datetime

# ===================== FILE STORAGE ===================== #

PATIENTS_FILE = "patients.json"
APPOINTMENTS_FILE = "appointments.json"
FEEDBACKS_FILE = "feedbacks.json"
AMBULANCE_FILE = "ambulance_bookings.json"
PAYMENTS_FILE = "payments.json"

# ===================== DATA STORAGE ===================== #

patients = {}
appointments = []
feedbacks = []
ambulance_bookings = []
payments = []

# ===================== LOAD & SAVE FUNCTIONS ===================== #

def load_data():
    global patients, appointments, feedbacks, ambulance_bookings, payments
    patients = json.load(open(PATIENTS_FILE)) if os.path.exists(PATIENTS_FILE) else {}
    appointments = json.load(open(APPOINTMENTS_FILE)) if os.path.exists(APPOINTMENTS_FILE) else []
    feedbacks = json.load(open(FEEDBACKS_FILE)) if os.path.exists(FEEDBACKS_FILE) else []
    ambulance_bookings = json.load(open(AMBULANCE_FILE)) if os.path.exists(AMBULANCE_FILE) else []
    payments = json.load(open(PAYMENTS_FILE)) if os.path.exists(PAYMENTS_FILE) else []

def save_data():
    json.dump(patients, open(PATIENTS_FILE, "w"), indent=4)
    json.dump(appointments, open(APPOINTMENTS_FILE, "w"), indent=4)
    json.dump(feedbacks, open(FEEDBACKS_FILE, "w"), indent=4)
    json.dump(ambulance_bookings, open(AMBULANCE_FILE, "w"), indent=4)
    json.dump(payments, open(PAYMENTS_FILE, "w"), indent=4)

# ===================== STATIC DATA ===================== #

consultation_fees = {
    "General": 300,
    "Cardiology": 800,
    "Neurology": 900,
    "Orthopedics": 700,
    "Gynecology": 600,
    "Pediatrics": 500,
    "ENT": 400,
    "Oncology": 1000,
    "Emergency": 1200
}

AMBULANCE_FEE = 1500

doctors = [
    {"id": 1, "name": "Dr. Rao", "dept": "General"},
    {"id": 2, "name": "Dr. Priya", "dept": "Cardiology"},
    {"id": 3, "name": "Dr. Anand", "dept": "Neurology"},
    {"id": 4, "name": "Dr. Kavya", "dept": "Orthopedics"},
    {"id": 5, "name": "Dr. Meena", "dept": "Gynecology"},
    {"id": 6, "name": "Dr. Arjun", "dept": "Pediatrics"},
    {"id": 7, "name": "Dr. Sneha", "dept": "ENT"},
    {"id": 8, "name": "Dr. Varun", "dept": "Oncology"},
    {"id": 9, "name": "Dr. Emergency", "dept": "Emergency"}
]

# ✅ ADDED (WAS MISSING)
ambulances = [
    {"id": 1, "type": "Basic Life Support"},
    {"id": 2, "type": "Advanced Life Support"},
    {"id": 3, "type": "ICU Ambulance"}
]

# ===================== VALIDATIONS ===================== #

def valid_email(email):
    return "@" in email and "." in email

def duplicate_mobile(mobile):
    return any(p["mobile"] == mobile for p in patients.values())

def aadhaar_validation():
    a = input("Enter Aadhaar Number (12 digits): ")
    return a.isdigit() and len(a) == 12

def otp_verification():
    otp = random.randint(1000, 9999)
    print("📨 OTP Sent:", otp)
    return input("Enter OTP: ") == str(otp)

def get_doctor(did):
    for d in doctors:
        if d["id"] == did:
            return d
    return None

# ===================== CORE FUNCTIONS ===================== #

def register_patient():
    name = input("Enter Name: ")

    while True:
        email = input("Enter Email: ")
        if valid_email(email):
            break
        print("❌ Invalid Email")

    while True:
        mobile = input("Enter Mobile (10 digits): ")
        if mobile.isdigit() and len(mobile) == 10 and not duplicate_mobile(mobile):
            break
        print("❌ Invalid / Duplicate Mobile")

    if not aadhaar_validation():
        print("❌ Aadhaar Validation Failed")
        return

    if not otp_verification():
        print("❌ OTP Verification Failed")
        return

    pid = "PAT-" + str(uuid.uuid4())[:6]
    patients[pid] = {"name": name, "email": email, "mobile": mobile}
    save_data()

    print("✅ Registration Successful")
    print("Patient ID:", pid)

def view_patients():
    print("\n👥 REGISTERED PATIENTS")
    for pid, p in patients.items():
        print(pid, "|", p["name"], "|", p["email"], "|", p["mobile"])

def book_appointment(pid):
    print("\n🩺 AVAILABLE DOCTORS")
    for d in doctors:
        print(d["id"], d["name"], "-", d["dept"])

    did = int(input("Select Doctor ID: "))
    date = input("Enter Date (DD/MM/YYYY): ")

    print("""
Appointment Type:
1. Normal
2. Emergency
3. Online Consultation
""")
    atype = input("Enter choice: ")

    status = "Confirmed"
    mode = "Offline"

    if atype == "2":
        status = "Emergency"
        print("🚨 Emergency Appointment Activated")
        ambulance_services(pid)     # auto ambulance
    elif atype == "3":
        mode = "Online"
        print("💬 Online Consultation Scheduled")

    appointment = {
        "pid": pid,
        "doctor": did,
        "date": date,
        "status": status,
        "mode": mode,
        "time": datetime.now().strftime("%H:%M")
    }

    appointments.append(appointment)
    save_data()

    print("✅ Appointment Booked")
    print("📄 Digital prescription will be generated after consultation")


def view_appointments(pid):
    print("\n📋 APPOINTMENT HISTORY")
    for i, a in enumerate(appointments):
        if a["pid"] == pid:
            print(i, a)

def reschedule_appointment(pid):
    view_appointments(pid)
    index = int(input("Enter appointment index to reschedule: "))
    appointments[index]["date"] = input("Enter new date: ")
    appointments[index]["status"] = "Rescheduled"
    save_data()
    print("✅ Appointment Rescheduled")

def cancel_appointment(pid):
    view_appointments(pid)
    index = int(input("Enter appointment index to cancel: "))
    appointments[index]["status"] = "Cancelled"
    save_data()
    print("❌ Appointment Cancelled")

def make_payment(pid):
    for a in reversed(appointments):
        if a["pid"] == pid:
            doctor = get_doctor(a["doctor"])
            amount = consultation_fees[doctor["dept"]]
            now = datetime.now().strftime("%d-%m-%Y %H:%M")
            payments.append({"pid": pid, "type": "Consultation", "amount": amount, "time": now})
            save_data()
            print(f"💳 Payment Successful ₹{amount} on {now}")
            return
    print("❌ No appointment found")

# ===================== AMBULANCE ===================== #

def live_ambulance_tracking():
    print("📍 Ambulance is on the way...")
    for i in range(3, 0, -1):
        print(f"🚑 Arriving in {i} minutes")
        time.sleep(1)
    print("✅ Ambulance has arrived")

def ambulance_services(pid):
    print("\n🚑 AMBULANCE SERVICES")
    for a in ambulances:
        print(a["id"], "-", a["type"])

    choice = int(input("Select Ambulance ID: "))

    ambulance_bookings.append({"pid": pid, "ambulance_id": choice})
    payments.append({
        "pid": pid,
        "type": "Ambulance",
        "amount": AMBULANCE_FEE,
        "time": datetime.now().strftime("%d-%m-%Y %H:%M")
    })
    save_data()

    print(f"🚑 Ambulance Booked | Bill ₹{AMBULANCE_FEE}")
    live_ambulance_tracking()

def admin_revenue():
    print("📊 TOTAL HOSPITAL REVENUE: ₹", sum(p["amount"] for p in payments))

# ===================== START PROGRAM ===================== #


def login_patient():
    pid = input("Enter Patient ID: ")
    if pid in patients:
        print("✅ Login Successful")
        patient_menu(pid)
    else:
        print("❌ Invalid Patient ID")
def patient_menu(pid):
    while True:
        print("""
1. View Doctors
2. Book Appointment
3. View Appointments
4. Reschedule Appointment
5. Cancel Appointment
6. Payment
7. Ambulance Service
0. Logout
""")
        ch = input("Enter choice: ")

        if ch == "1":
            for d in doctors:
                print(d["id"], d["name"], "-", d["dept"])
        elif ch == "2":
            book_appointment(pid)
        elif ch == "3":
            view_appointments(pid)
        elif ch == "4":
            reschedule_appointment(pid)
        elif ch == "5":
            cancel_appointment(pid)
        elif ch == "6":
            make_payment(pid)
        elif ch == "7":
            ambulance_services(pid)
        elif ch == "0":
            break
        else:
            print("Invalid option")

def give_feedback(pid):
    doctor = input("Enter Doctor Name: ")
    rating = input("Rate (1-5): ")
    comment = input("Enter Feedback: ")

    feedbacks.append({
        "pid": pid,
        "doctor": doctor,
        "rating": rating,
        "comment": comment,
        "time": datetime.now().strftime("%d-%m-%Y %H:%M")
    })
    save_data()
    print("⭐ Feedback submitted successfully")


load_data()

while True:
    print("""
🏥 CITY SUPER SPECIALITY HOSPITAL
1. Patient Registration
2. Patient Login
3. View All Patients (Admin)
4. Book Appointment
5. Make Payment
6. Book Ambulance
7. Admin Revenue
8. View Appointments
9. Reschedule Appointment
10. Cancel Appointment
11. Give Feedback
0. Exit
""")

    ch = input("Enter choice: ")

    if ch == "1":
        register_patient()
    elif ch == "2":
        login_patient()
    elif ch == "3":
        view_patients()
    elif ch == "4":
        book_appointment(input("Enter Patient ID: "))
    elif ch == "5":
        make_payment(input("Enter Patient ID: "))
    elif ch == "6":
        ambulance_services(input("Enter Patient ID: "))  # ✅ FIXED
    elif ch == "7":
        admin_revenue()
    elif ch == "8":
        view_appointments(input("Enter Patient ID: "))
    elif ch == "9":
        reschedule_appointment(input("Enter Patient ID: "))
    elif ch == "10":
        cancel_appointment(input("Enter Patient ID: "))
    elif ch == "11":
        give_feedback(input("Enter Patient ID: "))
    elif ch == "0":
        print("Thank you! Stay Healthy.")
        break
    else:
        print("Invalid option")
